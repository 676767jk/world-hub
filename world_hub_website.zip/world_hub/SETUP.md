# Publish World Hub — setup guide

You can do these steps with a trusted adult if you need help creating hosting/database accounts.

## 1. Create the database and login system
1. Open https://supabase.com/ and create a project.
2. Save the database password somewhere private. Do not share it.
3. In the project, open **SQL Editor**.
4. Open `schema.sql` from this download, copy all its contents and run it.
5. In **Authentication → Providers → Email**, keep email sign-up enabled and turn on email confirmation.
6. In **Project Settings → API**, copy the Project URL and the public anon/publishable key.

## 2. Connect the website
1. Make a copy of `config.example.js` named exactly `config.js`.
2. Replace the example URL and key with your Supabase Project URL and public anon/publishable key.
3. Keep `config.js` beside `index.html`.
4. Do not use the `service_role` key. It must never appear in a website.

## 3. Make yourself the owner
1. Open `index.html` on a local web server or publish it privately first.
2. Create your own World Hub account and confirm your email.
3. In Supabase, open **Authentication → Users** and copy your account's UUID.
4. Go to **SQL Editor** and run this command, replacing the placeholder with your UUID:

   `update public.profiles set is_admin = true where id = 'YOUR_AUTH_USER_UUID';`

5. Sign out and sign back in. You should now see **Owner dashboard** in the account area.
6. Never promote anyone else unless you intend to give them owner-level control.

## 4. Publish it for worldwide access
1. Create a GitHub account and a new repository named `world-hub`.
2. Upload `index.html`, `styles.css`, `app.js`, and your `config.js`.
3. In repository **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. GitHub Pages will show the public website address after it deploys.

Anyone with the address can visit the public page. Users still need accounts to chat.

## 5. Before inviting lots of people
This starter is a foundation. Before opening a large public chat, add:
- Message rate limits and spam protection (e.g. Supabase Edge Function or database throttling).
- User blocking, report review workflow, and a clear community rules page.
- Stronger account recovery and admin audit logs.
- A moderation plan and an easy way to contact the site owner.
- A privacy policy explaining what account and message data is stored.

The game links open in a new tab. A third-party game may block embedding, so World Hub opens the original site instead.
