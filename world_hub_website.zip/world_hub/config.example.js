// Copy this file to config.js and add your project's public anon/publishable key.
// NEVER put a service_role key or database password in browser code.
window.WORLD_HUB_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_PUBLIC_ANON_KEY"
};
