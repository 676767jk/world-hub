# World Hub

A dark-themed gaming and chat website starter.

## Included
- Landing page and featured links to the three gaming sites you supplied.
- Supabase email/password sign-up and sign-in.
- Worldwide public group chat with realtime updates.
- One-to-one private messages (only sender and recipient can read them).
- Report-message flow and owner report dashboard.
- Owner status is assigned server-side in the database, not from browser input.

## Important: this download is a starter, not yet a live public website
The visual preview works immediately, but real accounts and cross-device chat require a Supabase project and public hosting. No account or database has been created for you. Follow `SETUP.md`.

## Files
- `index.html` — page structure
- `styles.css` — responsive dark gaming design
- `app.js` — sign-in, chat, direct messages, reports, owner dashboard
- `schema.sql` — database tables and row-level security policies
- `config.example.js` — safe browser config template

## Safety and privacy
- Use a unique password and enable email confirmation in Supabase.
- Never publish a Supabase service-role key in this website.
- Private messages are readable only by their sender and recipient through database policies.
- The owner dashboard is restricted by a database admin flag.
- This starter includes reporting but not automated content moderation, blocking, rate limits, or age verification. Add these before promoting a large public community. Do not collect sensitive personal information.
