// World Hub — Supabase-powered chat starter.
// Add your Supabase URL and anon key in config.js (copy config.example.js).
const CONFIG = window.WORLD_HUB_CONFIG || {};
const hasConfig = Boolean(CONFIG.supabaseUrl && CONFIG.supabaseAnonKey);
const supabase = hasConfig ? window.supabase.createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey) : null;
const $ = (id) => document.getElementById(id);
let currentUser = null, profile = null, selectedMember = null, authMode = "signin", realtime = [], toastTimer;

$("year").textContent = new Date().getFullYear();
const toast = (msg) => { $("toast").textContent = msg; $("toast").classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>$("toast").classList.remove("show"),2800); };
const initials = (s) => (s || "?").trim().slice(0,1).toUpperCase();
const escapeHTML = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt = (s) => new Date(s).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"});
function showDemoNotice(){ $("connection").innerHTML="<i></i> Demo mode"; $("connection").style.color="#f2c77b"; }
function setTab(tab){
  document.querySelectorAll(".side-tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
  $("worldPanel").classList.toggle("hidden",tab!=="world"); $("directPanel").classList.toggle("hidden",tab!=="direct");
  $("chatTitle").textContent=tab==="world"?"◎ World Chat":"✉ Direct Messages";
  $("chatSubtitle").textContent=tab==="world"?"A shared space for the World Hub community":"Private one-to-one conversations";
  if(tab==="direct" && currentUser) loadMembers();
}
document.querySelectorAll(".side-tab").forEach(b=>b.addEventListener("click",()=>setTab(b.dataset.tab)));
$("authOpen").onclick=()=>openAuth("signin"); $("authClose").onclick=()=>$("authDialog").close();
$("adminClose").onclick=()=>$("adminDialog").close(); $("adminOpen").onclick=()=>openAdmin();
function openAuth(mode){authMode=mode;$("authHeading").textContent=mode==="signin"?"Sign in":"Create your account";$("authSubmit").textContent=mode==="signin"?"Sign in":"Create account";$("usernameLabel").classList.toggle("hidden",mode==="signin");$("authSwitch").textContent=mode==="signin"?"New here? Create an account":"Already have an account? Sign in";$("authError").textContent="";$("authDialog").showModal();}
$("authSwitch").onclick=()=>openAuth(authMode==="signin"?"signup":"signin");
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault(); if(!supabase){$("authError").textContent="Connect Supabase first — see SETUP.md in your download.";return;}
  const email=$("authEmail").value.trim(), password=$("authPassword").value, username=$("authUsername").value.trim();
  $("authSubmit").disabled=true;
  try{
    if(authMode==="signup"){
      if(username.length<3) throw new Error("Username must be at least 3 characters.");
      const {data,error}=await supabase.auth.signUp({email,password,options:{data:{username}}}); if(error)throw error;
      if(data.session){toast("Account created!");$("authDialog").close();} else {$("authError").textContent="Check your email to confirm your account, then sign in.";}
    }else{const {error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;$("authDialog").close();toast("Welcome back!");}
  }catch(err){$("authError").textContent=err.message||"Something went wrong.";}finally{$("authSubmit").disabled=false;}
});
$("signOut").onclick=async()=>{if(supabase)await supabase.auth.signOut();};
$("worldForm").addEventListener("submit",async e=>{e.preventDefault();const content=$("worldInput").value.trim();if(!content||!currentUser||!supabase)return; $("worldInput").value="";const {error}=await supabase.from("messages").insert({user_id:currentUser.id,content});if(error)toast(error.message);});
$("dmForm").addEventListener("submit",async e=>{e.preventDefault();const content=$("dmInput").value.trim();if(!content||!currentUser||!selectedMember||!supabase)return;$("dmInput").value="";const {error}=await supabase.from("direct_messages").insert({sender_id:currentUser.id,recipient_id:selectedMember.id,content});if(error)toast(error.message);});
$("memberSearch").addEventListener("input",()=>loadMembers($("memberSearch").value));
async function loadProfile(){
  const {data,error}=await supabase.from("profiles").select("id,username,is_admin,is_banned").eq("id",currentUser.id).single();
  if(error){toast("Could not load profile. Check the database setup.");return;}
  profile=data;
  if(profile.is_banned){await supabase.auth.signOut();toast("This account is restricted.");return;}
  $("accountName").textContent=profile.username;$("accountAvatar").textContent=initials(profile.username);$("accountStatus").textContent=profile.is_admin?"Site owner":"Member";
  $("adminOpen").classList.toggle("hidden",!profile.is_admin);
}
async function refreshAuth(session){
  currentUser=session?.user||null;
  $("authOpen").classList.toggle("hidden",!!currentUser);$("signOut").classList.toggle("hidden",!currentUser);
  $("worldInput").disabled=!currentUser;$("worldForm").querySelector("button").disabled=!currentUser;
  $("dmInput").disabled=!currentUser;$("dmForm").querySelector("button").disabled=!currentUser;
  if(!currentUser){profile=null;selectedMember=null;$("accountName").textContent="Guest visitor";$("accountAvatar").textContent="?";$("accountStatus").textContent="Sign in to chat";$("adminOpen").classList.add("hidden");renderEmpty("messages","Sign in to join World Chat","Create an account to send and receive community messages.");renderEmpty("dmMessages","Your private chats","Sign in and choose a member to start a private conversation.");$("memberList").innerHTML='<p class="muted small-pad">Sign in to find members.</p>';return;}
  await loadProfile();await loadWorldMessages();subscribe();
}
function renderEmpty(id,title,desc){$(id).innerHTML=`<div class="empty-state"><div class="empty-icon">◎</div><b>${escapeHTML(title)}</b><p>${escapeHTML(desc)}</p></div>`;}
function renderMessages(id,rows,allowReport=true){
  const el=$(id);if(!rows.length){renderEmpty(id,"No messages yet","Start the conversation.");return;}
  el.innerHTML=rows.map(m=>`<article class="message" data-message="${m.id}"><div class="avatar">${escapeHTML(initials(m.profiles?.username))}</div><div class="message-body"><div class="message-meta">${escapeHTML(m.profiles?.username||"Member")}<time>${fmt(m.created_at)}</time>${allowReport&&m.user_id!==currentUser?.id?`<button class="message-tools" data-report="${m.id}">Report</button>`:""}</div><div class="message-text">${escapeHTML(m.content)}</div></div></article>`).join("");
  el.querySelectorAll("[data-report]").forEach(b=>b.onclick=()=>reportMessage(b.dataset.report));
  el.scrollTop=el.scrollHeight;
}
async function loadWorldMessages(){
  const {data,error}=await supabase.from("messages").select("id,user_id,content,created_at,profiles(username)").order("created_at",{ascending:true}).limit(100);
  if(error){toast(error.message);return;}renderMessages("messages",data||[]);
}
function subscribe(){
  realtime.forEach(c=>supabase.removeChannel(c));realtime=[];
  const world=supabase.channel("world-messages").on("postgres_changes",{event:"INSERT",schema:"public",table:"messages"},()=>loadWorldMessages()).subscribe();realtime.push(world);
  const dm=supabase.channel("my-dms").on("postgres_changes",{event:"INSERT",schema:"public",table:"direct_messages"},p=>{if(selectedMember&&(p.new.sender_id===selectedMember.id||p.new.recipient_id===selectedMember.id))loadDMs();}).subscribe();realtime.push(dm);
}
async function loadMembers(filter=""){
  if(!currentUser)return;
  const {data,error}=await supabase.from("profiles").select("id,username").neq("id",currentUser.id).eq("is_banned",false).ilike("username",`%${filter.replace(/[%_]/g,"")}%`).order("username").limit(50);
  if(error){$("memberList").innerHTML='<p class="muted small-pad">Could not load members.</p>';return;}
  $("memberList").innerHTML=(data||[]).map(m=>`<button class="member-item ${selectedMember?.id===m.id?"selected":""}" data-id="${m.id}"><span class="avatar">${escapeHTML(initials(m.username))}</span>${escapeHTML(m.username)}</button>`).join("")||'<p class="muted small-pad">No members found.</p>';
  $("memberList").querySelectorAll("[data-id]").forEach(b=>b.onclick=()=>{selectedMember=data.find(m=>m.id===b.dataset.id);$("memberList").querySelectorAll(".member-item").forEach(x=>x.classList.toggle("selected",x===b));loadDMs();});
}
async function loadDMs(){
  if(!selectedMember)return;
  const {data,error}=await supabase.from("direct_messages").select("id,sender_id,recipient_id,content,created_at").or(`and(sender_id.eq.${currentUser.id},recipient_id.eq.${selectedMember.id}),and(sender_id.eq.${selectedMember.id},recipient_id.eq.${currentUser.id})`).order("created_at").limit(100);
  if(error){toast(error.message);return;}
  const rows=(data||[]).map(m=>({...m,profiles:{username:m.sender_id===currentUser.id?profile.username:selectedMember.username}}));
  renderMessages("dmMessages",rows,false);$("dmInput").disabled=false;$("dmForm").querySelector("button").disabled=false;
}
async function reportMessage(messageId){
  const reason=prompt("Briefly describe why you are reporting this message:");if(!reason)return;
  const {error}=await supabase.from("reports").insert({reporter_id:currentUser.id,message_id:messageId,reason:reason.slice(0,500)});
  toast(error?error.message:"Report sent to the site owner. Thank you.");
}
async function openAdmin(){
  if(!profile?.is_admin)return;
  $("adminDialog").showModal();$("adminContent").innerHTML='<p class="muted">Loading reports…</p>';
  const {data,error}=await supabase.from("reports").select("id,reason,created_at,message_id,reporter_id").eq("resolved",false).order("created_at",{ascending:false}).limit(30);
  if(error){$("adminContent").textContent=error.message;return;}
  $("adminContent").innerHTML=(data||[]).map(r=>`<div class="report-row"><div><b>Report #${r.id.slice(0,8)}</b><p>${escapeHTML(r.reason)}</p><small class="muted">${new Date(r.created_at).toLocaleString()}</small></div><div><button data-resolve="${r.id}">Resolve</button></div></div>`).join("")||'<p class="muted">No unresolved reports. Nice work keeping the community safe.</p>';
  $("adminContent").querySelectorAll("[data-resolve]").forEach(b=>b.onclick=async()=>{const {error}=await supabase.from("reports").update({resolved:true}).eq("id",b.dataset.resolve);if(error)toast(error.message);else openAdmin();});
}
if(hasConfig){
  $("connection").innerHTML="<i></i> Connected";$("connection").style.color="#75dcb6";
  supabase.auth.getSession().then(({data})=>refreshAuth(data.session));
  supabase.auth.onAuthStateChange((_event,session)=>{refreshAuth(session);});
}else{showDemoNotice();renderEmpty("messages","Preview mode","The layout is ready. Connect Supabase to enable real accounts and live worldwide chat.");}
