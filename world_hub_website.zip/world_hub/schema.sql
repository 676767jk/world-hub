-- World Hub database setup for Supabase.
-- Run this whole file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 24),
  is_admin boolean not null default false,
  is_banned boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 1000),
  created_at timestamptz not null default now(),
  check (sender_id <> recipient_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  reason text not null check (char_length(reason) between 1 and 500),
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

-- Create a profile automatically after a verified auth signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare chosen_username text;
begin
  chosen_username := coalesce(nullif(new.raw_user_meta_data ->> 'username',''), 'player_' || substr(new.id::text,1,8));
  insert into public.profiles(id, username) values(new.id, chosen_username);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Helper checks admin status from the protected profiles table.
create or replace function public.is_world_hub_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists(select 1 from public.profiles where id = (select auth.uid()) and is_admin = true and is_banned = false);
$$;

alter table public.profiles enable row level security;
alter table public.messages enable row level security;
alter table public.direct_messages enable row level security;
alter table public.reports enable row level security;

-- Profiles: signed-in members can see public usernames. No client-side update policy
-- is granted, so users cannot promote themselves or alter ban/admin flags.
drop policy if exists "profiles readable by signed in users" on public.profiles;
create policy "profiles readable by signed in users" on public.profiles for select to authenticated
using (is_banned = false or id = (select auth.uid()) or public.is_world_hub_admin());

-- Public group chat: authenticated, non-banned members can read and post.
drop policy if exists "members read world messages" on public.messages;
create policy "members read world messages" on public.messages for select to authenticated using (true);
drop policy if exists "members post own world messages" on public.messages;
create policy "members post own world messages" on public.messages for insert to authenticated
with check (user_id = (select auth.uid()) and not exists(select 1 from public.profiles p where p.id = (select auth.uid()) and p.is_banned));

drop policy if exists "owner deletes world messages" on public.messages;
create policy "owner deletes world messages" on public.messages for delete to authenticated using (public.is_world_hub_admin());

-- Direct messages: only sender and recipient can read; sender can send as self.
drop policy if exists "participants read direct messages" on public.direct_messages;
create policy "participants read direct messages" on public.direct_messages for select to authenticated
using ((sender_id = (select auth.uid()) or recipient_id = (select auth.uid())) and not exists(select 1 from public.profiles p where p.id = (select auth.uid()) and p.is_banned));
drop policy if exists "members send direct messages" on public.direct_messages;
create policy "members send direct messages" on public.direct_messages for insert to authenticated
with check (sender_id = (select auth.uid()) and not exists(select 1 from public.profiles p where p.id = (select auth.uid()) and p.is_banned));

-- Reports: users can submit reports; only the owner can view and resolve them.
drop policy if exists "members submit reports" on public.reports;
create policy "members submit reports" on public.reports for insert to authenticated
with check (reporter_id = (select auth.uid()));
drop policy if exists "owner manages reports" on public.reports;
create policy "owner manages reports" on public.reports for all to authenticated
using (public.is_world_hub_admin()) with check (public.is_world_hub_admin());

-- Enable realtime updates for both chat tables.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.direct_messages;
exception when duplicate_object then null;
when undefined_object then null;
end $$;

-- IMPORTANT: After you create your own account, promote ONLY your account.
-- Replace YOUR_AUTH_USER_UUID with your UUID from Authentication > Users.
-- Run this separately in SQL Editor:
-- update public.profiles set is_admin = true where id = 'YOUR_AUTH_USER_UUID';
